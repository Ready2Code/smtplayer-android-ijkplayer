#!/usr/bin/env python

print ("=====Yeah=====")