from django.shortcuts import render
from django.shortcuts import HttpResponse
import os
import sys
import json
import socket

# Create your views here.

def index(request):
    #request.POST
    #request.GET
    #return HttpResponse("hello world!")
    return render(request, "index.html",)

def acall(request):
    #from jnius import cast
    #from jnius import autoclass

    #Intent = autoclass('android.content.Intent')
    #Uri = autoclass('android.net.Uri')

    #intent = Intent()
    #intent.setAction(Intent.ACTION_CALL)
    #intent.setData(Uri.parse('tel:111-333-222-4'))

    #startActivity(intent)
    PATH1 = os.getcwd()
    print PATH1
    print len(sys.argv)
    print sys.argv[0]
    PORT1 = 4355
    #print sys.argv[1]
    #print os.path.abspath('.')
    #print os.path.abspath('..')
    #f = os.popen('ls -a').read()
    #print f
    s1 = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    myurl = "file:///data/data/com.example.testapp/files/testvedio.mp4"
    s1.sendto(myurl, ('localhost', PORT1))
    print "Success send ..."
    s1.close()


    #channel1 = load("channels.json")
    #channel2 = load("/data/data/com.example.testdjango/files/mysite/channels.json")
    #print channel1
    #print channel2

    return HttpResponse(u"ok", content_type='application/json')

def load(name):
    with open(name) as json_file:
        data = json.load(json_file)
        return data