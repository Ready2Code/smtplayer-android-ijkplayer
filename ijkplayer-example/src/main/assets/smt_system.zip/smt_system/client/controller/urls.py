from django.conf.urls import url
from views import start_controller,cplay_channel

urlpatterns = [
]

start_controller('')
cplay_channel('','1')

